<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
  <style>
    .containerrrrr {
      width: 370px;
      height: 330px;
      background-color: #fff;
      overflow-y: hidden;
      border-radius: 10px;
    }

    @media only screen and (min-width: 1098px) {
      .day {
        width: 40px;
        height: 23px !important;
        padding: 5px 13px !important;
        font-size: 10px !important;
        margin: 5.9px !important;
        box-sizing: border-box;
        box-shadow: 0px 0px 3px #cbd4c2;
        color: #7f8fa6;
        display: flex;
        flex-direction: column;
      }

      .containerrrrr {
        width: 370px;
        height: 250px;
        background-color: #fff;
        overflow-y: hidden;
        border-radius: 10px;
      }
    }

    .headercal {
      padding: 10px;
      display: flex;
      justify-content: space-between;
    }

    .headercal #month {
      color: #000;
      padding-left: 50px;
      font-size: 20px;
      font-weight: 600;
    }

    button {
      width: 75px;
      cursor: pointer;
      border: none;
      outline: none;
      padding: 5px;
      border-radius: 3px;
      color: white;
    }

    .headercal button {
      width: 20px;
      height: 30px;
      background: linear-gradient(180deg, #12a6cc 0%, #035793 100%);
    }

    .weekdays {
      width: 100%;
      display: flex;
      background-color: #2f3640;
      font-size: 13px;
      color: #fff;
    }

    #calendar {
      width: 100%;
      margin: auto;
      display: flex;
      flex-wrap: wrap;
    }

    .weekdays div {
      width: 90px;
      text-align: center;
      text-transform: uppercase;
    }

    .day {
      width: 40px;
      height: 40px;
      padding: 11px;
      cursor: pointer;
      margin: 4.5px;
      box-sizing: border-box;
      box-shadow: 0px 0px 3px #cbd4c2;
      color: #7f8fa6;
      display: flex;
      flex-direction: column;
      transition: background-color 1s;
    }

    .day:hover {
      background-color: rgba(112, 111, 211, 0.1);
      color: #706fd3;
    }

    #currentDay {
      background-color: #706fd3;
      color: #fff;
    }

    .event {
      font-size: 10px;
      padding: 3px;
      background-color: #3d3d3d;
      color: #fff;
      border-radius: 5px;
      max-height: 55px;
      overflow: hidden;
    }

    .event.holiday {
      background-color: palegreen;
      color: red;
    }

    .plain {
      cursor: default;
      box-shadow: none;
    }

    #modal {
      display: none;
      position: absolute;
      top: 0px;
      left: 0px;
      width: 100vw;
      height: 100vh;
      z-index: 10;
      background-color: rgba(0, 0, 0, 0.8);
    }

    #addEvent,
    #viewEvent {
      display: none;
      width: 350px;
      background-color: #fff;
      padding: 25px;
      position: absolute;
      z-index: 20;
    }

    #addEvent h2,
    #viewEvent h2 {
      font-weight: 500;
      margin-bottom: 10px;
    }

    #txtTitle {
      padding: 10px;
      width: 100%;
      box-sizing: border-box;
      margin-bottom: 25px;
      border-radius: 3px;
      outline: none;
      border: 1px solid #cbd4c2;
      font-size: 16px;
    }

    #btnSave {
      background-color: #2ed573;
    }

    .btnClose {
      background-color: #2f3542;
    }

    #viewEvent p {
      margin-bottom: 20px;
    }

    #btnDelete {
      background-color: #ea2027;
    }

    .error {
      border-color: #ea2027 !important;
    }

    /* Animation for holiday background color */
    @keyframes changeColor {
      0% {
        background-color: red;
      }

      50% {
        background-color: orange;
      }

      100% {
        background-color: red;
      }
    }

    .holiday-animation {
      animation: changeColor 1s infinite;
    }
  </style>
</head>

<body>
  <div class="containerrrrr">
    <div class="headercal">
      <div id="month"></div>
      <div>
        <button id="btnBack"><i class="fa fa-angle-left"></i></button>
        <button id="btnNext"><i class="fa fa-angle-right"></i></button>
      </div>
    </div>
    <div class="weekdays">
      <div>Sun</div>
      <div>Mon</div>
      <div>Tue</div>
      <div>Wed</div>
      <div>Thu</div>
      <div>Fri</div>
      <div>Sat</div>
    </div>
    <div id="calendar"></div>
  </div>
  <div id="modal"></div>
  <div id="addEvent">
    <h2>Add Event</h2>
    <input type="text" id="txtTitle" placeholder="Event Title" />
    <button id="btnSave">Save</button>
    <button class="btnClose">Close</button>
  </div>

  <div id="viewEvent">
    <h2>Event</h2>
    <p id="eventText">This is Sample Event</p>
    <button id="btnDelete">Delete</button>
    <button class="btnClose">Close</button>
  </div>

  <script>
    const holidays = [{
        hdate: "12-11-2024",
        holiday: "36th Conference of the International Society for Fluoride Research (ISFR)"
      },
      {
        hdate: "13-11-2024",
        holiday: "36th Conference of the International Society for Fluoride Research (ISFR)"
      },
      {
        hdate: "14-11-2024",
        holiday: "36th Conference of the International Society for Fluoride Research (ISFR)"
      },

    ];

    const calendar = document.querySelector("#calendar");
    const monthBanner = document.querySelector("#month");
    let navigation = (new Date(2024, 10) - new Date(new Date().getFullYear(), new Date().getMonth())) / (1000 * 60 * 60 * 24 * 30);
    let clicked = null;
    let events = localStorage.getItem("events") ? JSON.parse(localStorage.getItem("events")) : [];
    const weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    function loadCalendar() {
      const dt = new Date();
      dt.setMonth(dt.getMonth() + navigation);

      const day = dt.getDate();
      const month = dt.getMonth();
      const year = dt.getFullYear();
      monthBanner.innerText = `${dt.toLocaleDateString("en-us", { month: "long" })} ${year}`;
      calendar.innerHTML = "";

      const dayInMonth = new Date(year, month + 1, 0).getDate();
      const firstDayofMonth = new Date(year, month, 1);
      const dateText = firstDayofMonth.toLocaleDateString("en-us", {
        weekday: "long",
        year: "numeric",
        month: "numeric",
        day: "numeric"
      });

      const dayString = dateText.split(", ")[0];
      const emptyDays = weekdays.indexOf(dayString);

      for (let i = 1; i <= dayInMonth + emptyDays; i++) {
        const dayBox = document.createElement("div");
        dayBox.classList.add("day");
        const monthVal = month + 1 < 10 ? "0" + (month + 1) : month + 1;
        const dateVal = i - emptyDays < 10 ? "0" + (i - emptyDays) : i - emptyDays;
        const dateText = `${dateVal}-${monthVal}-${year}`;

        if (i > emptyDays) {
          dayBox.innerText = i - emptyDays;
          const eventOfTheDay = events.find((e) => e.date === dateText);
          const holidayOfTheDay = holidays.find((e) => e.hdate === dateText);

          if (i - emptyDays === day && navigation === 0) {
            dayBox.id = "currentDay";
          }

          if (eventOfTheDay) {
            const eventDiv = document.createElement("div");
            eventDiv.classList.add("event");
            eventDiv.innerText = eventOfTheDay.title;
            dayBox.appendChild(eventDiv);
          }
          if (holidayOfTheDay) {
            const eventDiv = document.createElement("div");
            eventDiv.classList.add("event", "holiday");
            eventDiv.innerText = holidayOfTheDay.holiday;
            dayBox.appendChild(eventDiv);
            dayBox.addEventListener("click", () => {
              alert(holidayOfTheDay.holiday);
            });
          }

          dayBox.addEventListener("click", () => {
            showModal(dateText);
          });
        } else {
          dayBox.classList.add("plain");
        }
        calendar.append(dayBox);
      }
    }

    function buttons() {
      const btnBack = document.querySelector("#btnBack");
      const btnNext = document.querySelector("#btnNext");
      const btnDelete = document.querySelector("#btnDelete");
      const btnSave = document.querySelector("#btnSave");
      const closeButtons = document.querySelectorAll(".btnClose");
      const txtTitle = document.querySelector("#txtTitle");

      btnBack.addEventListener("click", () => {
        navigation--;
        loadCalendar();
      });
      btnNext.addEventListener("click", () => {
        navigation++;
        loadCalendar();
      });
      modal.addEventListener("click", closeModal);
      closeButtons.forEach((btn) => {
        btn.addEventListener("click", closeModal);
      });
      btnDelete.addEventListener("click", function() {
        events = events.filter((e) => e.date !== clicked);
        localStorage.setItem("events", JSON.stringify(events));
        closeModal();
      });

      btnSave.addEventListener("click", function() {
        if (txtTitle.value) {
          txtTitle.classList.remove("error");
          events.push({
            date: clicked,
            title: txtTitle.value.trim(),
          });
          txtTitle.value = "";
          localStorage.setItem("events", JSON.stringify(events));
          closeModal();
        } else {
          txtTitle.classList.add("error");
        }
      });
    }

    const modal = document.querySelector("#modal");
    const viewEventForm = document.querySelector("#viewEvent");
    const addEventForm = document.querySelector("#addEvent");

    function showModal(dateText) {
      clicked = dateText;
      const eventOfTheDay = events.find((e) => e.date == dateText);
      if (eventOfTheDay) {
        document.querySelector("#eventText").innerText = eventOfTheDay.title;
        viewEventForm.style.display = "none";
        addEventForm.style.display = "none";
      } else {
        addEventForm.style.display = "none";
        viewEventForm.style.display = "none";
      }
      modal.style.display = "none";
    }

    function closeModal() {
      viewEventForm.style.display = "none";
      addEventForm.style.display = "none";
      modal.style.display = "none";
      clicked = null;
      loadCalendar();
    }

    buttons();
    loadCalendar();
  </script>
</body>

</html>