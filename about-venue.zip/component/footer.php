     <div class="container-fluid bg-[#002946]">
       <div class="conatiner mx-auto  text-white p-4">
         <div class=" flex  items-center justify-evenly  footer">
           <div class="  foot1 flex gap-2 items-center ">
             <div class=" ">





               <ul class="text-[13px] flex flex-col gap-1">
                 <li class="text-[20px] pb-4">Conference Secretariat </li>
                 <li>
                 Office of the Organizing Chairperson Prof. A Shariff,
                 </li>
                 <li>Room No-2, Convergence Block, AIIMS, Ansari, Nagar
                 </li>
                 <li>New Delhi, India, PIN: 110029</li>
               </ul>
             </div>
             <div class=" ">
               <ul class="text-[13px] flex flex-col gap-1">
                 <li class="text-[20px] pb-4"> Organizing Secretary
 </li>
                 <li>Dr. Javed Ahsan Quadri
</li>

                 <li>Email: javedaiims@gmail.com

                 </li>
                 <li>Mobile No: +91-9555034947 
                 </li>
               </ul>
             </div>

           </div>
           <!-- =================================================== -->
           <div class=" mr-10 foot2">
             <span class="text-sm px-2 pb-4"> Days to go </span>
             <div class="text-white  flex border gap-[5px] border-b-2 border-0">

               <div class="flex flex-col items-center justify-between py-2">
                 <span id="daysss" class="text-2xl"> </span>
                 <span class="text-[15px]">Days</span>
               </div>
               &nbsp; <span class="py-[14px]">:</span>
               <div class="flex flex-col items-center py-2">
                 <span id="hoursss" class="text-2xl"></span>
                 <span class="text-[15px]">Hours</span>
               </div>
               &nbsp; <span class="py-[14px]">:</span>
               <div class="flex flex-col items-center py-2">
                 <span id="minutesss" class="text-2xl"></span>
                 <span class="text-[15px]">Minutes</span>
               </div>
               &nbsp; <span class="py-[14px]">:</span>
               <div class="flex flex-col items-center py-2">
                 <span id="secondsss" class="text-2xl"></span>
                 <span class="text-[15px]">Seconds</span>
               </div>
             </div>
           </div>
           <?php include("calender.php"); ?>




           <!-- ========================================= -->

         </div>
         <p class="text-center text-[13px] pt-4 fot-p">© Copyright All Right Reserved</p>
       </div>
     </div>
     </div>
     <script src="script.js"></script>
     </body>

     </html>